public class Main {
    public static void main(String[] args) {
        Libro libro = new Libro(1, "George Orwell", "1984", true);
        Socio socio = new Socio(101, "Juan Pérez", "654987321", 30);
        Prestamo prestamo = new Prestamo("01/04/2025", "15/04/2025", 0.0);

        libro.mostrarInfo();
        System.out.println();
        socio.mostrarInfo();
        System.out.println();
        prestamo.mostrarInfo();
    }
}
