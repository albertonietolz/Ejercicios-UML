public class Peces extends Animal {
	private String tipoDeAgua;

	public Peces(String nombreCientifico, String habitat, String tipoDeAgua) {
		super(nombreCientifico, habitat);
		this.tipoDeAgua = tipoDeAgua;
	}

	public void nadar() {
		System.out.println("El pez está nadando.");
	}

	@Override
	public void mostrarInfo() {
		super.mostrarInfo();
		System.out.println("Tipo de agua: " + tipoDeAgua);
	}
}
