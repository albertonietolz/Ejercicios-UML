public class Gatos extends Animal {
	private String raza;

	public Gatos(String nombreCientifico, String habitat, String raza) {
		super(nombreCientifico, habitat);
		this.raza = raza;
	}

	public void maullar() {
		System.out.println("El gato está maullando.");
	}

	@Override
	public void mostrarInfo() {
		super.mostrarInfo();
		System.out.println("Raza: " + raza);
	}
}
