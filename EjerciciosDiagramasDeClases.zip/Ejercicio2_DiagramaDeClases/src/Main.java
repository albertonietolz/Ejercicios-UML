public class Main {
	public static void main(String[] args) {
		Peces pez = new Peces("Salmo salar", "Ríos y océanos", "Agua dulce");
		Perros perro = new Perros("Canis lupus familiaris", "Doméstico", "Labrador");
		Gatos gato = new Gatos("Felis catus", "Doméstico", "Siamés");

		pez.mostrarInfo();
		pez.respirar();
		pez.nadar();

		System.out.println();

		perro.mostrarInfo();
		perro.respirar();
		perro.ladrar();

		System.out.println();

		gato.mostrarInfo();
		gato.respirar();
		gato.maullar();
	}
}
