public class Prestamo {
    private String fechaEntrega;
    private String fechaDevolucion;
    private double penalizacion;

    public Prestamo(String fechaEntrega, String fechaDevolucion, double penalizacion) {
        this.fechaEntrega = fechaEntrega;
        this.fechaDevolucion = fechaDevolucion;
        this.penalizacion = penalizacion;
    }

    public void multa() {
    }

    public void mostrarInfo() {
        System.out.println("Fecha de Entrega: " + fechaEntrega);
        System.out.println("Fecha de Devolución: " + fechaDevolucion);
        System.out.println("Penalización: " + penalizacion + "€");
    }
}
