public class Persona {
	private String dni;
	private String nombre;
	private String telefono;
	private int edad;

	public Persona(String dni, String nombre, String telefono, int edad) {
		this.dni = dni;
		this.nombre = nombre;
		this.telefono = telefono;
		this.edad = edad;
	}

	public void anda() {
		System.out.println(nombre + " está andando.");
	}

	public void corre() {
		System.out.println(nombre + " está corriendo.");
	}

	public void llama(String numero) {
		System.out.println(nombre + " está llamando al " + numero);
	}

	public void mostrarInfo() {
		System.out.println("DNI: " + dni);
		System.out.println("Nombre: " + nombre);
		System.out.println("Teléfono: " + telefono);
		System.out.println("Edad: " + edad);
	}
}
