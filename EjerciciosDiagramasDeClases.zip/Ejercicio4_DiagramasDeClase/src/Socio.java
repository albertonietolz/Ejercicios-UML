public class Socio {
    private int id;
    private String nombre;
    private String telefono;
    private int edad;

    public Socio(int id, String nombre, String telefono, int edad) {
        this.id = id;
        this.nombre = nombre;
        this.telefono = telefono;
        this.edad = edad;
    }

    public void entregarLibro() {
        // Método vacío
    }

    public void recibirLibro() {
        // Método vacío
    }

    public void mostrarInfo() {
        System.out.println("ID: " + id);
        System.out.println("Nombre: " + nombre);
        System.out.println("Teléfono: " + telefono);
        System.out.println("Edad: " + edad);
    }
}
