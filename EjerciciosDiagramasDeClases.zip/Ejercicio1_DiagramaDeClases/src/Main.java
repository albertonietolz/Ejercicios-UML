public class Main {
	public static void main(String[] args) {
		Persona antonio = new Persona("4893493P", "Antonio Rodríguez Pérez", "843943932", 39);
		antonio.mostrarInfo();
		antonio.anda();
		antonio.corre();
		antonio.llama("654321987");
	}
}
