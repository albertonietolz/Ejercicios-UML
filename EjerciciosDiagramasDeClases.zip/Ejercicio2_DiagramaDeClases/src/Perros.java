public class Perros extends Animal {
	private String raza;

	public Perros(String nombreCientifico, String habitat, String raza) {
		super(nombreCientifico, habitat);
		this.raza = raza;
	}

	public void ladrar() {
		System.out.println("El perro está ladrando.");
	}

	@Override
	public void mostrarInfo() {
		super.mostrarInfo();
		System.out.println("Raza: " + raza);
	}
}
