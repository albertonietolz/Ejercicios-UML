public class Libro {
    private int id;
    private String autor;
    private String titulo;
    private boolean disponible;

    public Libro(int id, String autor, String titulo, boolean disponible) {
        this.id = id;
        this.autor = autor;
        this.titulo = titulo;
        this.disponible = disponible;
    }

    public void disponibilidad() {
        // Método vacío
    }

    public void mostrarInfo() {
        System.out.println("ID: " + id);
        System.out.println("Autor: " + autor);
        System.out.println("Título: " + titulo);
        System.out.println("Disponible: " + (disponible ? "Sí" : "No"));
    }
}
