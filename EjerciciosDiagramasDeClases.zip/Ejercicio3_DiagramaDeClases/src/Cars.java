public class Cars extends Persona {
	private String combustible;
	private String marca;
	private String modelo;

	public Cars(String dni, String nombre, String telefono, int edad, String combustible, String marca, String modelo) {
		super(dni, nombre, telefono, edad);
		this.combustible = combustible;
		this.marca = marca;
		this.modelo = modelo;
	}

	public void acelerar() {
		System.out.println(marca + " " + modelo + " está acelerando.");
	}

	public void frenar() {
		System.out.println(marca + " " + modelo + " está frenando.");
	}

	public void claxon() {
		System.out.println(marca + " " + modelo + " está tocando el claxon.");
	}

	@Override
	public void mostrarInfo() {
		super.mostrarInfo();
		System.out.println("Combustible: " + combustible);
		System.out.println("Marca: " + marca);
		System.out.println("Modelo: " + modelo);
	}
}
