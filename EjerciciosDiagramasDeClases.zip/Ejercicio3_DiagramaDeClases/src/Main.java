public class Main {
    public static void main(String[] args) {
        Cars coche = new Cars("4893493P", "Antonio Rodríguez Pérez", "843943932", 39, "Gasolina", "Toyota", "Corolla");

        coche.mostrarInfo();
        coche.acelerar();
        coche.frenar();
        coche.claxon();
    }
}
