public class Animal {
	private String nombreCientifico;
	private String habitat;

	public Animal(String nombreCientifico, String habitat) {
		this.nombreCientifico = nombreCientifico;
		this.habitat = habitat;
	}

	public void respirar() {
		System.out.println("El animal está respirando.");
	}

	public void mostrarInfo() {
		System.out.println("Nombre científico: " + nombreCientifico);
		System.out.println("Hábitat: " + habitat);
	}
}
